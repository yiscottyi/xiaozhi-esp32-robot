#ifndef __MOTOR_SERVO_CONTROLLER_H__
#define __MOTOR_SERVO_CONTROLLER_H__

#include <esp_log.h>
#include <driver/gpio.h>
#include <driver/ledc.h>
#include <cstring>

#include "mcp_server.h"

#define TAG_MOTOR "MotorServo"

// 动作指令枚举
enum RobotAction {
    kActionStop = 0,
    kActionForward,
    kActionBackward,
    kActionTurnLeft,
    kActionTurnRight,
};

class MotorServoController {
private:
    bool initialized_ = false;
    gpio_num_t in1_ = GPIO_NUM_NC;
    gpio_num_t in2_ = GPIO_NUM_NC;
    gpio_num_t in3_ = GPIO_NUM_NC;
    gpio_num_t in4_ = GPIO_NUM_NC;
    gpio_num_t servo_pin_ = GPIO_NUM_NC;
    ledc_channel_t servo_channel_ = LEDC_CHANNEL_0;
    int servo_angle_ = 90; // 默认90度（居中）

    // 设置单个电机方向和转速
    void SetMotor(gpio_num_t inA, gpio_num_t inB, bool forward) {
        gpio_set_level(inA, forward ? 1 : 0);
        gpio_set_level(inB, forward ? 0 : 1);
    }

    void StopMotor(gpio_num_t inA, gpio_num_t inB) {
        gpio_set_level(inA, 0);
        gpio_set_level(inB, 0);
    }

    // 设置舵机角度 (0-180)，使用LEDC PWM
    void SetServoPwm(int angle) {
        if (servo_pin_ == GPIO_NUM_NC) return;
        // 限制角度范围
        if (angle < 0) angle = 0;
        if (angle > 180) angle = 180;
        servo_angle_ = angle;
        // 50Hz, 0.5ms-2.5ms 对应 0-180度
        // duty = (0.5 + angle/180.0 * 2.0) / 20.0 * 65535
        uint32_t duty = (500 + angle * 2000 / 180) * 65535 / 20000;
        ledc_set_duty(LEDC_LOW_SPEED_MODE, servo_channel_, duty);
        ledc_update_duty(LEDC_LOW_SPEED_MODE, servo_channel_);
    }

public:
    MotorServoController() = default;

    // 初始化 L298N 引脚和舵机 PWM
    void Initialize(gpio_num_t in1, gpio_num_t in2, gpio_num_t in3, gpio_num_t in4,
                    gpio_num_t servo_pin, ledc_channel_t servo_channel = LEDC_CHANNEL_0) {
        if (initialized_) {
            ESP_LOGW(TAG_MOTOR, "Already initialized");
            return;
        }
        in1_ = in1;
        in2_ = in2;
        in3_ = in3;
        in4_ = in4;
        servo_pin_ = servo_pin;
        servo_channel_ = servo_channel;

        // 配置电机方向引脚
        gpio_config_t io_conf = {
            .pin_bit_mask = (1ULL << in1) | (1ULL << in2) | (1ULL << in3) | (1ULL << in4),
            .mode = GPIO_MODE_OUTPUT,
            .pull_up_en = GPIO_PULLUP_DISABLE,
            .pull_down_en = GPIO_PULLDOWN_DISABLE,
            .intr_type = GPIO_INTR_DISABLE,
        };
        ESP_ERROR_CHECK(gpio_config(&io_conf));
        StopMotor(in1_, in2_);
        StopMotor(in3_, in4_);

        // 配置舵机 PWM (LEDC)
        if (servo_pin != GPIO_NUM_NC) {
            ledc_timer_config_t timer_conf = {
                .speed_mode = LEDC_LOW_SPEED_MODE,
                .duty_resolution = LEDC_TIMER_16_BIT,
                .timer_num = LEDC_TIMER_1,
                .freq_hz = 50,
                .clk_cfg = LEDC_AUTO_CLK,
            };
            ledc_timer_config(&timer_conf);

            ledc_channel_config_t channel_conf = {
                .gpio_num = servo_pin,
                .speed_mode = LEDC_LOW_SPEED_MODE,
                .channel = servo_channel,
                .intr_type = LEDC_INTR_DISABLE,
                .timer_sel = LEDC_TIMER_1,
                .duty = 0,
                .hpoint = 0,
            };
            ESP_ERROR_CHECK(ledc_channel_config(&channel_conf));
            SetServoPwm(90); // 初始居中
        }

        initialized_ = true;
        ESP_LOGI(TAG_MOTOR, "MotorServoController initialized");

        // 注册 MCP 工具（AI 可见）
        auto& mcp = McpServer::GetInstance();
        mcp.AddTool("self.robot.move",
            "Control the robot movement. Supported directions: forward, backward, left, right, stop.",
            PropertyList({ Property("direction", kPropertyTypeString) }),
            [this](const PropertyList& properties) -> ReturnValue {
                auto dir = properties["direction"].value<std::string>();
                if (dir == "forward") {
                    MoveForward();
                    return "Robot moving forward";
                } else if (dir == "backward") {
                    MoveBackward();
                    return "Robot moving backward";
                } else if (dir == "left") {
                    TurnLeft();
                    return "Robot turning left";
                } else if (dir == "right") {
                    TurnRight();
                    return "Robot turning right";
                } else if (dir == "stop") {
                    Stop();
                    return "Robot stopped";
                }
                return "Unknown direction";
            });

        mcp.AddTool("self.robot.set_servo",
            "Set the servo angle (0-180 degrees). 90 is the center.",
            PropertyList({ Property("angle", kPropertyTypeInteger, 0, 180) }),
            [this](const PropertyList& properties) -> ReturnValue {
                int angle = properties["angle"].value<int>();
                SetServoAngle(angle);
                return "Servo set to " + std::to_string(angle) + " degrees";
            });
    }

    bool IsInitialized() const { return initialized_; }

    void MoveForward() {
        if (!initialized_) return;
        ESP_LOGI(TAG_MOTOR, "Action: Forward");
        SetMotor(in1_, in2_, true);
        SetMotor(in3_, in4_, true);
    }

    void MoveBackward() {
        if (!initialized_) return;
        ESP_LOGI(TAG_MOTOR, "Action: Backward");
        SetMotor(in1_, in2_, false);
        SetMotor(in3_, in4_, false);
    }

    void TurnLeft() {
        if (!initialized_) return;
        ESP_LOGI(TAG_MOTOR, "Action: Turn Left");
        // 左电机后退，右电机前进，原地左转
        SetMotor(in1_, in2_, false);
        SetMotor(in3_, in4_, true);
    }

    void TurnRight() {
        if (!initialized_) return;
        ESP_LOGI(TAG_MOTOR, "Action: Turn Right");
        // 左电机前进，右电机后退，原地右转
        SetMotor(in1_, in2_, true);
        SetMotor(in3_, in4_, false);
    }

    void Stop() {
        if (!initialized_) return;
        ESP_LOGI(TAG_MOTOR, "Action: Stop");
        StopMotor(in1_, in2_);
        StopMotor(in3_, in4_);
    }

    void SetServoAngle(int angle) {
        if (!initialized_) return;
        ESP_LOGI(TAG_MOTOR, "Servo angle: %d", angle);
        SetServoPwm(angle);
    }

    int GetServoAngle() const { return servo_angle_; }

    // 执行指定动作
    void ExecuteAction(RobotAction action) {
        switch (action) {
            case kActionForward:  MoveForward();  break;
            case kActionBackward: MoveBackward(); break;
            case kActionTurnLeft: TurnLeft();     break;
            case kActionTurnRight:TurnRight();    break;
            default:              Stop();         break;
        }
    }
};

// 全局单例访问
static inline MotorServoController& GetMotorServoController() {
    static MotorServoController instance;
    return instance;
}

#endif // __MOTOR_SERVO_CONTROLLER_H__
